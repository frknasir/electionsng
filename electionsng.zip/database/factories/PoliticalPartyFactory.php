<?php

use Faker\Generator as Faker;

$factory->define(App\PoliticalParty::class, function (Faker $faker) {
    return [
        //
    ];
});
