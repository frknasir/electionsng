<?php

use Faker\Generator as Faker;

$factory->define(App\ElectionType::class, function (Faker $faker) {
    return [
        //
    ];
});
