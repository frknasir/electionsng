<?php

use Faker\Generator as Faker;

$factory->define(App\Election::class, function (Faker $faker) {
    return [
        //
    ];
});
