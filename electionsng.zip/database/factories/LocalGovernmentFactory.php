<?php

use Faker\Generator as Faker;

$factory->define(App\LocalGovernment::class, function (Faker $faker) {
    return [
        //
    ];
});
