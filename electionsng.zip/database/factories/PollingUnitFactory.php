<?php

use Faker\Generator as Faker;

$factory->define(App\PollingUnit::class, function (Faker $faker) {
    return [
        //
    ];
});
