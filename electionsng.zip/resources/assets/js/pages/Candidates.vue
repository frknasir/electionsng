<style scoped>

</style>
<template>
    <router-view></router-view>
</template>
<script>
    export default {
        data() {
            return {

            };
        },
        components: {
            
        },
        created() {

        }
    }
</script>
