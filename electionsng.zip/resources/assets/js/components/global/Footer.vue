<style>

</style>
<template>
    <footer class="footer">
        <div class="container">
            <nav class="float-left">
                <ul>
                    <li>
                        <a href="https://electionsng.com">
                            &copy; 2018, Electionsng.com
                        </a>
                    </li>
                </ul>
            </nav>
            <!-- your footer here -->
        </div>
    </footer>
</template>
<script>
export default {
    
}
</script>
